
# 方法列表
英文原文：http://www.phpconcept.net/pclzip/user-guide/21

- PclZip::PclZip() : 构造函数
- PclZip::create() : 创建 PKZIP 压缩包，并向其添加文件和目录
- PclZip::listContent() : 列出压缩包中的内容
- PclZip::extract() : 提取压缩包中的所有或部分内容
- PclZip::properties() : 获取压缩包的属性信息
- PclZip::add() : 向压缩包中添加文件或目录
- PclZip::delete() : 删除压缩包中的内容
- PclZip::merge() : 将一个压缩包的所有内容添加到另一个压缩包
- PclZip::duplicate() : 复制压缩包
