

# 一些命令
```sh
gitbook init

gitbook install

gitbook serve

```

# serve 错误
https://github.com/GitbookIO/gitbook/issues/1309
https://github.com/GitbookIO/gitbook/blob/3.2.2/lib/output/website/copyPluginAssets.js#L112


