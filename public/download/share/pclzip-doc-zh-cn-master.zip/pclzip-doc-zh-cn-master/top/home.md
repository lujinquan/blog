
# 概述
英文原文：http://www.phpconcept.net/pclzip

PclZip 库用于对 zip 格式文件进行压缩和解压（WinZip，PKZIP）。

PclZip 提供的功能包括：
- 创建 zip 压缩包
- 显示 zip 压缩包内文件列表
- 解压 zip 包内的文件

PclZip 定义了一个对象类来表示 zip 压缩包，通过此类你可获取或操作 zip 的内容。